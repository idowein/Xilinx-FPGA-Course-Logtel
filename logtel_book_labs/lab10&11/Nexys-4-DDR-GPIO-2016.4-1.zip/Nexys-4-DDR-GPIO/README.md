# Nexys 4 DDR GPIO <!-- Replace this line with the project name -->
Created for Vivado 2016.4

[Link to the project wiki](https://reference.digilentinc.com/learn/programmable-logic/tutorials/nexys-4-ddr-gpio-demo/start)

